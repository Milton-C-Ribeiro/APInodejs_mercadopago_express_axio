const express = require('express');
const axios = require('axios'); // Import axios for making HTTP requests
const app = express();
const port = 3060; // Define the port for your API

// Set the Mercado Pago API base URL
const mercadoPagoBaseUrl = 'https://api.mercadopago.com';

// Set your Mercado Pago access token (replace with your actual token)
const mercadoPagoToken = 'TEST-7147373714146655-112713-ecb41c300cfb3fdf187a6c37458ea009-2086572509';

// Define your API endpoint
app.get('/mercadopago/payments', async (req, res) => {
  try {
    // Construct the Mercado Pago API endpoint URL
    const apiEndpoint = `${mercadoPagoBaseUrl}/v1/payments`;

    // Create the Axios configuration with the access token
    const config = {
      headers: {
        Authorization: `Bearer ${mercadoPagoToken}`,
      },
    };

    // Make the API request to Mercado Pago
    const response = await axios.get(apiEndpoint, config);

    // Send the response from Mercado Pago to your API consumer
    res.json(response.data);
  } catch (error) {
    console.error('Error fetching data from Mercado Pago:', error);
    res.status(500).json({ error: 'Failed to retrieve data from Mercado Pago' });
  }
});

app.get("/", (req, res) => {
  res.send("Hello World!" + Date.now());
});


app.get("/pagar ", async (req, res) => {

var id = "" + Date.now();
var emailDoPagador = "mcr.milton@gmail.com";

  var dados = {
    items: [
      item = {
        id: id,
        title: 'Toalha de Banho',
        description: 'Toalha 8x1.20',
        category_id: 'banho',
        quantity: 1,
        currency_id: 'BRL',
        unit_price: parseFloat(150.99).toFixed(2)
      }
    ],
    payer: {
      email: emailDoPagador,
      },
      external_reference: id,
  };
  try {
    var pagamento = await mercadoPago.preferences.create(dados);
    console.log(pagamento);
    return res.redirect(pagamento.body.init_point);
  } catch (error) {
    console.log(error);
    return res.send('Erro ao fazer o pagamento');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`API server listening at http://localhost:${port}`);
});
